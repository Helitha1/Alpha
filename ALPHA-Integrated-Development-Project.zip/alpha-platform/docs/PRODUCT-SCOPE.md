# ALPHA product scope

## Product decision
International-first (B), custom ALPHA visual identity (C), complete platform direction (C). The primary viewing interaction is a full-screen vertical swipe feed. Reactions are Like, Love, Haha, Wow, Sad and Angry.

## MVP release 0.1
1. Account registration/login (Firebase Auth integration required).
2. Vertical For You and Following feeds.
3. Video upload, metadata, playback and thumbnail pipeline.
4. Emoji reactions, comments, follows, shares and creator profiles.
5. Search, hashtags and basic discovery.
6. Notifications (FCM integration required).
7. Reporting, blocking, moderation queue and admin roles.
8. Recommendation API baseline and event collection.

## Later releases
- Direct messaging and live streaming.
- In-app video editing, licensed audio catalogue and effects.
- Creator analytics, monetization and advertising.
- ML ranking trained on aggregated, privacy-reviewed interaction data.

## Recommendation principles
The baseline ranker uses watch ratio, completion, rewatch, reactions, comments, shares, creator-follow affinity, topic affinity and freshness. It excludes blocked creators and reduces repeated exposure. Production ranking must also account for safety eligibility, user controls, content quality, language/region preferences, creator diversity, age suitability and feedback loops. Never use sensitive traits to infer interests.
