# Firebase setup for ALPHA

The Firebase project must be owned by the ALPHA operator. I cannot create a Firebase project or accept terms on your behalf, and no Firebase credentials are embedded in this source archive.

1. Open the Firebase console and create a project named ALPHA.
2. Add an Android app with package ID `com.alpha.app`.
3. Download `google-services.json` and place it in `android/app/`.
4. In Authentication → Sign-in method, enable Email/Password. Add Google sign-in only after configuring OAuth consent and SHA fingerprints.
5. Add Firebase Authentication SDK using the official Android setup instructions. Keep all service-account credentials on the server, never in the APK.
6. Before enabling writes, verify Firebase ID tokens in Spring Boot and derive user identity from the verified token; do not trust a client-supplied `userId`.
7. Add App Check / Play Integrity, email verification, password reset, account deletion and rate limits before release.

Official guide: https://firebase.google.com/docs/auth/android/start
