# Public launch checklist

- [ ] Register ALPHA domain and configure production DNS/TLS.
- [ ] Create Firebase project; enable Auth providers, FCM and App Check; add Android app package `com.alpha.app`.
- [ ] Select object storage/CDN and configure private buckets + signed uploads.
- [ ] Deploy managed PostgreSQL; rotate all local passwords; enable backups/PITR.
- [ ] Implement full auth, RBAC, account recovery, deletion and export.
- [ ] Implement upload validation, transcoding, HLS playback and CDN caching.
- [ ] Implement moderation/report/block/appeal workflows and safety policies.
- [ ] Add privacy policy, terms, community guidelines, copyright process and age rating.
- [ ] Load-test feed, uploads, playback, ranking and database; set SLOs and alerts.
- [ ] Complete security review, penetration test, accessibility and Play policy review.
- [ ] Configure analytics with consent/privacy controls and retention limits.
