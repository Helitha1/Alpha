# ALPHA Admin Console

## Run
1. Install Node.js 20 or newer.
2. `cd admin && npm install`
3. Copy `.env.example` to `.env` and set `VITE_ALPHA_API=http://localhost:8080/api`.
4. `npm run dev` for local preview or `npm run build` for a static production bundle.

## Screens
- Overview: KPI cards, platform analytics, growth breakdown, moderation queue, creator leaderboard and activity feed.
- Users: searchable user directory and local preview status toggle.
- Videos / Moderation / Reports: searchable moderation list with approve/remove preview actions.
- Analytics, Algorithm, Live streams, Monetization, Notifications, Audit logs and Settings: module workspaces and integration status.

## Security requirements before production
- Authenticate admins on the server; do not rely on hidden UI routes.
- Enforce RBAC for every admin API endpoint.
- Add MFA, CSRF protection where applicable, rate limiting and immutable audit events.
- Persist all moderation actions with actor, reason, timestamp and appeal state.
- Add pagination, filtering, export permissions and PII masking.
- Never ship seeded/demo metrics as real platform data.

Current user/video rows and actions are preview data. Only the API health check is wired in this admin build; admin mutations do not yet call secured persistence endpoints.
