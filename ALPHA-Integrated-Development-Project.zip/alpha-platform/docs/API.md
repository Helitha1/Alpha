# ALPHA API (prototype)

Base URL: `http://localhost:8080/api`

| Method | Path | Purpose |
|---|---|---|
| GET | `/health` | Health check |
| GET | `/feed?type=for-you` | Demo feed (test HLS clips until database-backed feed is connected) |
| POST | `/videos/upload` | Development multipart video upload (`file`, optional `creator`, `caption`) |
| POST | `/videos/{videoId}/reactions` | Prototype emoji reaction; JSON `{ "type": "LOVE", "userId": "demo-user" }` |
| POST | `/videos/{videoId}/events` | Prototype playback event; JSON `{ "type": "WATCH", "watchMs": 12000, "completed": false }` |

Reaction values: `LIKE`, `LOVE`, `HAHA`, `WOW`, `SAD`, `ANGRY`.
Event values: `IMPRESSION`, `WATCH`, `COMPLETE`, `REWATCH`, `SKIP`, `SHARE`, `COMMENT`.

Recommendation service: `POST http://localhost:8001/rank` with `{ "candidates": [...], "preferred_topics": [], "blocked_creator_ids": [] }`. See `recommender/app.py` for the complete candidate schema and score weights.

**Security warning:** the current upload, reaction and event endpoints are prototype endpoints. The client-provided user identifier is not authentication. Before internet exposure, implement Firebase ID-token verification, authorization, durable DB writes, rate limiting, moderation and audit logging.
