# ALPHA architecture

Android client (Kotlin/Compose/Media3) → API gateway / Spring Boot → PostgreSQL. Media uploads go directly to private object storage using short-lived signed upload URLs. An asynchronous worker validates, scans, transcodes and creates HLS renditions/thumbnails. CDN delivers playback. Event collector records impressions, watch duration, completion, rewatch, reaction and share events. Python ranking service scores eligible candidates. Firebase Auth verifies identity; FCM delivers push notifications.

## Required production services
- Object storage + CDN (choose region, data residency and egress pricing before selecting a vendor).
- Video transcoding queue/workers and malware/content scanning.
- Managed PostgreSQL with backups, point-in-time recovery and read replicas when needed.
- Redis or equivalent cache for feed/session/rate-limit workloads.
- Observability: structured logs, metrics, traces, crash reporting and alerting.
- Moderation: report intake, human review tools, automated nudity/violence/spam/copyright signals, appeals and audit trails.

## Security baseline
TLS everywhere; short-lived signed media URLs; server-side authorization; passwordless/OAuth or Firebase-managed credentials; App Check/device attestation; rate limits; upload size/duration limits; MIME sniffing; malware scanning; secrets manager; encrypted backups; admin MFA/RBAC; audit logs; account deletion/export; retention controls; privacy notice and age-appropriate safeguards.
