# ALPHA implementation status (MVP build)

This package implements the first development milestone for items 1–8. It is a working starter and local prototype, not yet a production social network.

| # | Requested capability | Included now | Still required for public production |
|---|---|---|---|
| 1 | Video upload | Android system video picker; backend multipart upload endpoint; local media serving | Authenticated upload, object storage, resumable upload, malware scanning, quotas and transcoding to HLS |
| 2 | Full-screen swipe player | Compose vertical pager + Media3 ExoPlayer HLS playback | Feed API integration, playback telemetry, adaptive preloading, device QA |
| 3 | Login / registration | Firebase integration setup guide and account flow requirements | Create Firebase project, register package `com.alpha.app`, add `google-services.json`, enable Email/Password and configure identity token verification in API |
| 4 | Reactions | Six reaction choices in Android UI; reaction API prototype; unique user/video schema | Authenticated persistence, aggregate counters, abuse limits |
| 5 | Comments / follows | Database schema and API roadmap | CRUD endpoints, moderation, notifications and Android screens |
| 6 | Recommendation engine | FastAPI rank endpoint with watch/completion/rewatch/reaction/share/topic/freshness signals and creator diversity | Event ingestion, offline evaluation, online experiments, safety constraints and model monitoring |
| 7 | Admin panel | React admin dashboard starter | Admin authentication/RBAC, live APIs, review actions, audit logs and appeals |
| 8 | APK | Android Studio Gradle project ready for local build | Build/sign on developer machine with Android SDK and release keystore; Play Console testing and policy review |

## Upload endpoint
`POST /api/videos/upload` as `multipart/form-data` with `file`, optional `creator`, and optional `caption`. Prototype limit is 150 MB. Files are stored in a local development directory and served from `/media/`. Do not expose this endpoint publicly until authentication, authorization, quotas, rate limits, virus scanning and cloud object storage are configured.

## Reaction endpoint
`POST /api/videos/{videoId}/reactions` JSON: `{ "type": "LOVE", "userId": "demo-user" }`. Supported types: LIKE, LOVE, HAHA, WOW, SAD, ANGRY. This is a prototype in-memory endpoint; the schema defines the persistent data model.

## Recommendation endpoint
`POST http://localhost:8001/rank` with candidate records; see `recommender/app.py` and `docs/API.md`.

## Important limitations
- Demo feed clips are public test streams and are not ALPHA user content.
- The Android Create screen opens the system video picker. It does not yet send the selected file because secure sign-in and upload token handling must be connected first.
- Firebase cannot be activated without an actual Firebase project and its app configuration. Do not put service account secrets in the Android app.
- Live streaming, DMs, creator monetization, copyright detection, content moderation automation, and scale-out CDN/transcoding are not implemented.
- Never deploy with the local Docker credentials. Replace them and use managed secrets.
