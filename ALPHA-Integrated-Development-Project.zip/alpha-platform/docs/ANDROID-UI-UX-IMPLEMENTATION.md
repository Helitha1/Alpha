# ALPHA Android UI/UX implementation

## Implemented Compose screens
- Welcome / splash-style entry
- Onboarding
- Login and registration form layouts (demo navigation; Firebase authentication still needs project credentials and token verification)
- Full-screen vertical HLS video feed (Media3 ExoPlayer) with For You presentation
- Facebook-style reaction picker (Like, Love, Haha, Wow, Sad, Angry)
- Comments dialog
- Discover search and category / hashtag layout
- Create / upload entry using Android system video picker
- Video editor and caption / metadata form layout (preview/effects/transcoding are placeholders)
- Inbox, chat layout
- Creator profile and settings
- Live-streaming preview (requires a configured ingest/playback provider)

## Brand tokens
- Background: `#080B1E`
- Card: `#171D38`
- Blue: `#3B82F6`
- Purple: `#8B5CF6`
- Magenta: `#D946EF`
- Text: `#F1F5FF`

## Run
Open `android/` in Android Studio, sync Gradle, then run `app` on an Android 8.0+ device/emulator with internet access.

## Integration boundary (important)
The current Android UI uses sample feed items and demo interaction state. The Spring Boot API and PostgreSQL schema are included in the repository, but the Android client is not yet wired to authenticated API calls. Before production, implement API client/repository calls, Firebase ID-token verification, persistent user/reaction/comment/follow endpoints, cloud object storage, HLS transcoding/CDN, push notifications, moderation workflows, and live streaming credentials. Login and registration screens are UI only until Firebase is configured. The upload picker selects a local video; publishing is not yet connected to remote storage from Android.

## Responsive behaviour
Compose layouts use flexible width, scroll containers and adaptive row/column arrangements for common phone sizes. Validate and refine on compact phones, large phones and tablets before release.
