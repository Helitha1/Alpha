# ALPHA video pipeline plan

Development upload endpoint currently stores original video files on the API host. For a public global platform, replace local disk storage with private object storage and a managed transcoding/CDN pipeline.

Recommended flow:
1. Client requests a short-lived upload authorization from the API after authentication and quota checks.
2. Client uploads directly to private object storage using a signed URL or resumable upload session.
3. Storage event queues a transcoding job.
4. Transcoder validates duration, dimensions, codecs and file safety; generates adaptive HLS renditions (for example 360p, 540p, 720p), thumbnails and poster frame.
5. Moderation checks run before the video is publicly discoverable.
6. API stores the HLS manifest URL and metadata; CDN serves the manifest and segments.
7. Android Media3 ExoPlayer consumes HLS and reports playback events to the API.

Do not store public upload credentials in the Android client. Configure signed URLs, per-user limits, content-type verification, actual file signature inspection, virus scanning, copyright reporting, age/privacy controls and retention/deletion policies.
