from datetime import datetime, timezone
from fastapi import FastAPI
from pydantic import BaseModel, Field
from typing import Optional

app = FastAPI(title="ALPHA Recommendation Service", version="0.1.0")

class Candidate(BaseModel):
    video_id: str
    creator_id: str
    topic: str = "general"
    watch_ratio: float = Field(0, ge=0, le=1)
    completed: bool = False
    rewatched: bool = False
    liked: bool = False
    reaction_weight: float = Field(0, ge=0, le=1)
    commented: bool = False
    shared: bool = False
    followed_creator: bool = False
    age_hours: float = Field(0, ge=0)
    seen_count: int = Field(0, ge=0)

class RankRequest(BaseModel):
    candidates: list[Candidate]
    preferred_topics: list[str] = []
    blocked_creator_ids: list[str] = []

@app.get("/health")
def health(): return {"service": "alpha-recommender", "status": "ok"}

@app.post("/rank")
def rank(payload: RankRequest):
    ranked = []
    for c in payload.candidates:
        if c.creator_id in payload.blocked_creator_ids or c.seen_count >= 3:
            continue
        topic_match = 1.0 if c.topic.lower() in {t.lower() for t in payload.preferred_topics} else 0.0
        freshness = max(0.0, 1.0 - c.age_hours / (24 * 7))
        score = (
            0.30 * c.watch_ratio + 0.20 * float(c.completed) +
            0.12 * float(c.rewatched) + 0.10 * float(c.liked) +
            0.08 * c.reaction_weight + 0.06 * float(c.commented) +
            0.08 * float(c.shared) + 0.03 * float(c.followed_creator) +
            0.02 * topic_match + 0.01 * freshness
        )
        ranked.append({"video_id": c.video_id, "score": round(score, 5), "topic": c.topic, "creator_id": c.creator_id})
    # Simple creator diversity: keep at most two consecutive candidates from one creator.
    ranked.sort(key=lambda x: x["score"], reverse=True)
    diversified, creator_counts = [], {}
    for item in ranked:
        if creator_counts.get(item["creator_id"], 0) < 2:
            diversified.append(item)
            creator_counts[item["creator_id"]] = creator_counts.get(item["creator_id"], 0) + 1
    return {"ranked": diversified, "generated_at": datetime.now(timezone.utc).isoformat(), "model": "transparent-baseline-v1"}
