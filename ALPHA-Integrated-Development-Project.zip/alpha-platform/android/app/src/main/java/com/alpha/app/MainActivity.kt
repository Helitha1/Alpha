package com.alpha.app

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.launch

private val Bg = Color(0xFF080B1E); private val Card = Color(0xFF171D38); private val Blue = Color(0xFF3B82F6)
private val Purple = Color(0xFF8B5CF6); private val Pink = Color(0xFFD946EF); private val Ink = Color(0xFFF1F5FF)
private val Muted = Color(0xFFAAB3CC)
private data class Clip(val id:String,val creator:String,val caption:String,val url:String,val sound:String,val views:String)
private val clips = listOf(
 Clip("demo-1","@alpha.explore","A new perspective. Welcome to ALPHA ✨ #Explore","https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8","Original sound · ALPHA","125.4K"),
 Clip("demo-2","@alpha.nature","Take a breath. The world is beautiful. 🌿 #Nature","https://test-streams.mux.dev/test_001/stream.m3u8","Nature ambience · ALPHA","82.1K")
)
private val reactions = listOf("👍" to "Like","❤️" to "Love","😂" to "Haha","😮" to "Wow","😢" to "Sad","😡" to "Angry")

class MainActivity:ComponentActivity(){ override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState); setContent { AlphaTheme { AlphaApp() } } } }
@Composable private fun AlphaTheme(content:@Composable()->Unit){ MaterialTheme(colorScheme=darkColorScheme(primary=Purple,secondary=Blue,background=Bg,surface=Card),content=content) }

@Composable private fun AlphaApp(){
 var page by remember { mutableStateOf("Welcome") }; var tab by remember { mutableStateOf("Home") }
 var reaction by remember { mutableStateOf("👍") }; var reactionOpen by remember { mutableStateOf(false) }; var commentsOpen by remember { mutableStateOf(false) }
 var selected by remember { mutableStateOf<Uri?>(null) }; var caption by remember { mutableStateOf("") }; var toast by remember { mutableStateOf("") }
 val picker=rememberLauncherForActivityResult(ActivityResultContracts.GetContent()){selected=it; if(it!=null) page="Editor"}
 when(page){
  "Welcome" -> WelcomeScreen({page="Onboarding"},{page="Login"})
  "Onboarding" -> OnboardingScreen({page="Login"},{page="Welcome"})
  "Login" -> AuthScreen({page="Main"},{page="Register"})
  "Register" -> AuthScreen({page="Main"},{page="Login"},true)
  "Editor" -> EditorScreen(selected,caption,{caption=it},{page="Main";tab="Home";toast="Video saved as a local draft"},{picker.launch("video/*")})
  "Live" -> LiveScreen({page="Main"})
  "Settings" -> SettingsScreen({page="Main"})
  "Chat" -> ChatScreen({page="Main"})
  else -> Scaffold(containerColor=Bg,bottomBar={ NavigationBar(containerColor=Color(0xFF0D1228)) {
   listOf("Home","Discover","Create","Inbox","Profile").forEach { t -> val icon=when(t){"Home"->Icons.Default.Home;"Discover"->Icons.Default.Search;"Create"->Icons.Default.AddBox;"Inbox"->Icons.Default.ChatBubbleOutline;else->Icons.Default.Person}
    NavigationBarItem(selected=tab==t,onClick={tab=t;if(t=="Create")picker.launch("video/*")},icon={Icon(icon,null)},label={Text(t)},colors=NavigationBarItemDefaults.colors(selectedIconColor=Ink,indicatorColor=Purple,selectedTextColor=Ink,unselectedTextColor=Muted)) }
  }}){ pad -> when(tab){
   "Home"->FeedScreen(pad,reaction,{reactionOpen=true},{commentsOpen=true},{page="Live"})
   "Discover"->DiscoverScreen(pad)
   "Create"->UploadScreen(pad,selected,{picker.launch("video/*")},{page="Editor"})
   "Inbox"->InboxScreen(pad,{page="Chat"})
   else->ProfileScreen(pad,{page="Settings"},{page="Chat"})
  }
  if(reactionOpen) ReactionDialog({reactionOpen=false}){reaction=it;reactionOpen=false;toast="You reacted $it"}
  if(commentsOpen) CommentsDialog({commentsOpen=false})
  if(toast.isNotBlank()) { LaunchedEffect(toast){ kotlinx.coroutines.delay(1800);toast="" }; SnackbarHost(remember{SnackbarHostState()},Modifier.padding(pad)) }
 }
 }
}

@Composable private fun Brand(){ Row(verticalAlignment=Alignment.CenterVertically){Box(Modifier.size(34.dp).clip(RoundedCornerShape(11.dp)).background(Brush.linearGradient(listOf(Blue,Purple,Pink))),contentAlignment=Alignment.Center){Text("A",fontSize=23.sp,fontWeight=FontWeight.Black,color=Ink)};Spacer(Modifier.width(9.dp));Text("ALPHA",fontSize=23.sp,fontWeight=FontWeight.Black,color=Ink,letterSpacing=2.sp)} }
@Composable private fun WelcomeScreen(next:()->Unit,login:()->Unit){ Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Bg,Color(0xFF17133D),Bg))),contentAlignment=Alignment.Center){Column(horizontalAlignment=Alignment.CenterHorizontally,modifier=Modifier.padding(28.dp)){Brand();Spacer(Modifier.height(26.dp));Text("Short Videos.\nBig Connections.",fontSize=32.sp,fontWeight=FontWeight.Bold,color=Ink,lineHeight=39.sp);Text("Discover · Create · Share · Connect",color=Muted,modifier=Modifier.padding(top=12.dp));Spacer(Modifier.height(34.dp));GradientButton("Get started",next);TextButton(onClick=login){Text("I already have an account",color=Ink)} }} }
@Composable private fun OnboardingScreen(next:()->Unit,back:()->Unit){Column(Modifier.fillMaxSize().background(Bg).padding(28.dp),verticalArrangement=Arrangement.Center,horizontalAlignment=Alignment.CenterHorizontally){Brand();Spacer(Modifier.height(45.dp));Text("Your world, in motion.",fontSize=29.sp,color=Ink,fontWeight=FontWeight.Bold);Text("Explore creators, share moments and connect through short videos.",color=Muted,modifier=Modifier.padding(vertical=18.dp));FeatureRow("▶","Watch a personalised video feed");FeatureRow("💜","React with expressive emojis");FeatureRow("✦","Find your next community");Spacer(Modifier.height(32.dp));GradientButton("Continue",next);TextButton(onClick=back){Text("Back",color=Muted)}}}
@Composable private fun AuthScreen(done:()->Unit,switch:()->Unit,register:Boolean=false){var email by remember{mutableStateOf("")};var password by remember{mutableStateOf("")};var name by remember{mutableStateOf("")};Column(Modifier.fillMaxSize().background(Bg).verticalScroll(rememberScrollState()).padding(24.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center){Brand();Spacer(Modifier.height(35.dp));Text(if(register)"Create your account" else "Welcome back",fontSize=27.sp,color=Ink,fontWeight=FontWeight.Bold);Text("${if(register)"Join" else "Sign in to"} the ALPHA community",color=Muted);Spacer(Modifier.height(25.dp));if(register)AlphaField("Display name",name,{name=it});AlphaField("Email or username",email,{email=it});AlphaField("Password",password,{password=it},true);Spacer(Modifier.height(18.dp));GradientButton(if(register)"Create account" else "Sign in",done);TextButton(onClick=switch){Text(if(register)"Already have an account? Sign in" else "New to ALPHA? Create account",color=Ink)};Text("Demo mode · connect Firebase Auth for secure accounts",fontSize=11.sp,color=Muted)} }
@Composable private fun AlphaField(label:String,value:String,onChange:(String)->Unit,secret:Boolean=false){OutlinedTextField(value,onChange,label={Text(label)},modifier=Modifier.fillMaxWidth().padding(vertical=6.dp),singleLine=true,visualTransformation=if(secret)androidx.compose.ui.text.input.PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None,colors=OutlinedTextFieldDefaults.colors(focusedTextColor=Ink,unfocusedTextColor=Ink,focusedBorderColor=Purple,unfocusedBorderColor=Muted,focusedLabelColor=Purple,unfocusedLabelColor=Muted))}
@Composable private fun GradientButton(text:String,onClick:()->Unit){Button(onClick=onClick,modifier=Modifier.fillMaxWidth().height(52.dp),shape=RoundedCornerShape(16.dp),colors=ButtonDefaults.buttonColors(containerColor=Purple)){Text(text,fontWeight=FontWeight.Bold,color=Ink)}}
@Composable private fun FeatureRow(icon:String,text:String){Row(Modifier.fillMaxWidth().padding(vertical=10.dp),verticalAlignment=Alignment.CenterVertically){Text(icon,fontSize=23.sp);Text(text,color=Ink,modifier=Modifier.padding(start=15.dp))}}

@Composable private fun FeedScreen(pad:PaddingValues,reaction:String,onReact:()->Unit,onComments:()->Unit,onLive:()->Unit){val pager=rememberPagerState(pageCount={clips.size});Box(Modifier.fillMaxSize().padding(pad).background(Bg)){VerticalPager(state=pager,modifier=Modifier.fillMaxSize()){idx->val clip=clips[idx];Box(Modifier.fillMaxSize()){VideoSurface(clip.url,pager.currentPage==idx);Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0x66000000),Color.Transparent,Color(0xCC000000)))));Row(Modifier.align(Alignment.TopCenter).padding(top=12.dp),horizontalArrangement=Arrangement.spacedBy(25.dp)){Text("Following",color=Muted);Text("For You",color=Ink,fontWeight=FontWeight.Bold)};Text("ALPHA",Modifier.align(Alignment.TopStart).padding(16.dp),color=Ink,fontWeight=FontWeight.Black,fontSize=20.sp);Column(Modifier.align(Alignment.BottomStart).padding(start=16.dp,end=82.dp,bottom=22.dp)){Text(clip.creator,color=Ink,fontWeight=FontWeight.Bold);Text(clip.caption,color=Ink,modifier=Modifier.padding(top=7.dp));Text("♫ ${clip.sound}",color=Ink,fontSize=12.sp,modifier=Modifier.padding(top=7.dp))};Column(Modifier.align(Alignment.CenterEnd).padding(end=13.dp),verticalArrangement=Arrangement.spacedBy(18.dp),horizontalAlignment=Alignment.CenterHorizontally){RoundAction("＋","Follow"){};RoundAction(reaction,"${clip.views}",onReact);RoundAction("💬","Comments",onComments);RoundAction("↗","Share"){};RoundAction("●","LIVE",onLive)}}}}}
@Composable private fun VideoSurface(url:String,active:Boolean){val ctx= LocalContext.current;val player=remember(url){ExoPlayer.Builder(ctx).build().apply{setMediaItem(MediaItem.fromUri(url));repeatMode=ExoPlayer.REPEAT_MODE_ONE;prepare()}};LaunchedEffect(active){if(active)player.play()else player.pause()};DisposableEffect(player){onDispose{player.release()}};AndroidView(factory={ctx -> PlayerView(ctx).apply { this.player = player; useController = false }},modifier=Modifier.fillMaxSize())}
@Composable private fun RoundAction(icon:String,label:String,click:()->Unit){Column(horizontalAlignment=Alignment.CenterHorizontally,modifier=Modifier.clickable{click()}){Box(Modifier.size(43.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Purple,Blue))),contentAlignment=Alignment.Center){Text(icon,color=Ink,fontSize=20.sp)};Text(label,color=Ink,fontSize=10.sp,modifier=Modifier.padding(top=3.dp))}}
@Composable private fun ReactionDialog(close:()->Unit,pick:(String)->Unit){AlertDialog(onDismissRequest=close,containerColor=Card,title={Text("React to this video",color=Ink)},text={Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){reactions.forEach{(emoji,name)->Column(horizontalAlignment=Alignment.CenterHorizontally,modifier=Modifier.clickable{pick(emoji)}){Text(emoji,fontSize=25.sp);Text(name,color=Ink,fontSize=10.sp)}}}},confirmButton={TextButton(onClick=close){Text("Close",color=Purple)}})}
@Composable private fun CommentsDialog(close:()->Unit){var comment by remember{mutableStateOf("")};AlertDialog(onDismissRequest=close,containerColor=Card,title={Text("Comments · 3,842",color=Ink)},text={Column{listOf("Amazing video! ❤️","Beautiful place 😍","ALPHA is looking great!").forEach{Text(it,color=Ink,modifier=Modifier.padding(vertical=8.dp))};AlphaField("Add a comment",comment,{comment=it})}},confirmButton={TextButton(onClick=close){Text("Post",color=Purple)}})}

@Composable private fun DiscoverScreen(pad:PaddingValues){var query by remember{mutableStateOf("")};Column(Modifier.fillMaxSize().padding(pad).background(Bg).verticalScroll(rememberScrollState()).padding(18.dp)){Text("Discover",fontSize=27.sp,color=Ink,fontWeight=FontWeight.Bold);AlphaField("Search users, videos, hashtags…",query,{query=it});Text("Explore categories",color=Ink,fontWeight=FontWeight.Bold,modifier=Modifier.padding(vertical=16.dp));listOf("🔥 Trending","♫ Music","🎮 Gaming","✈ Travel","🍜 Food","🌿 Nature","💻 Technology","😂 Comedy").chunked(2).forEach{Row{it.forEach{item->Surface(Modifier.weight(1f).padding(5.dp),color=Card,shape=RoundedCornerShape(14.dp)){Text(item,color=Ink,modifier=Modifier.padding(18.dp))}}}};Text("Trending hashtags",color=Ink,fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=20.dp));listOf("#SriLanka  ·  2.4M videos","#Travel  ·  8.1M videos","#Nature  ·  6.7M videos","#ALPHA  ·  120K videos").forEach{Text(it,color=Muted,modifier=Modifier.padding(vertical=10.dp))}}}
@Composable private fun UploadScreen(pad:PaddingValues,uri:Uri?,choose:()->Unit,edit:()->Unit){Column(Modifier.fillMaxSize().padding(pad).background(Bg).padding(22.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center){Text("Create",fontSize=28.sp,color=Ink,fontWeight=FontWeight.Bold);Text("Share your moment with the world",color=Muted);Spacer(Modifier.height(25.dp));FeatureRow("⬆","Upload a video from your device");FeatureRow("◉","Record a new video");FeatureRow("✦","Add music, text and effects");Spacer(Modifier.height(18.dp));GradientButton(if(uri==null)"Choose video" else "Edit selected video",if(uri==null)choose else edit);uri?.let{Text(it.lastPathSegment?:"Video selected",color=Muted,modifier=Modifier.padding(10.dp))}}}
@Composable private fun EditorScreen(uri:Uri?,caption:String,onCaption:(String)->Unit,publish:()->Unit,choose:()->Unit){Column(Modifier.fillMaxSize().background(Bg).verticalScroll(rememberScrollState()).padding(20.dp)){Row(verticalAlignment=Alignment.CenterVertically){Text("‹",fontSize=30.sp,color=Ink,modifier=Modifier.clickable{publish()});Text("  Edit video",fontSize=24.sp,color=Ink,fontWeight=FontWeight.Bold)};Spacer(Modifier.height(20.dp));Surface(color=Card,shape=RoundedCornerShape(20.dp),modifier=Modifier.fillMaxWidth().height(210.dp)){Column(Modifier.fillMaxSize(),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center){Icon(Icons.Default.VideoLibrary,null,tint=Purple,modifier=Modifier.size(48.dp));Text(uri?.lastPathSegment?:"Select a video",color=Ink);Text("Preview is shown after media pipeline setup",color=Muted,fontSize=11.sp)}};AlphaField("Write a caption…",caption,onCaption);FeatureRow("♫","Add sound");FeatureRow("✦","Effects and filters");FeatureRow("Aa","Text and stickers");FeatureRow("#","Add hashtags");GradientButton("Publish video",publish);TextButton(onClick=choose){Text("Choose another video",color=Muted)}}}
@Composable private fun InboxScreen(pad:PaddingValues,onOpen:()->Unit){Column(Modifier.fillMaxSize().padding(pad).background(Bg).padding(18.dp)){Text("Inbox",fontSize=27.sp,color=Ink,fontWeight=FontWeight.Bold);Text("Messages and activity",color=Muted);listOf("Nethmi Perera","Sadeesha Official","Dinuka Jay","ALPHA Updates").forEachIndexed{i,n->Row(Modifier.fillMaxWidth().clickable{onOpen()}.padding(vertical=14.dp),verticalAlignment=Alignment.CenterVertically){Avatar(n);Column(Modifier.padding(start=12.dp).weight(1f)){Text(n,color=Ink,fontWeight=FontWeight.SemiBold);Text(listOf("Are you coming today?","Liked your video","Sent you a video","Welcome to ALPHA!")[i],color=Muted,fontSize=12.sp)};Text(listOf("Now","2m","10m","1h")[i],color=Muted,fontSize=11.sp)}}}}
@Composable private fun ChatScreen(back:()->Unit){var msg by remember{mutableStateOf("")};Column(Modifier.fillMaxSize().background(Bg).padding(16.dp)){Text("‹  Messages",color=Ink,fontSize=23.sp,modifier=Modifier.clickable{back()});Spacer(Modifier.height(25.dp));Text("You are chatting in demo mode.",color=Muted);Spacer(Modifier.weight(1f));Row(verticalAlignment=Alignment.CenterVertically){OutlinedTextField(msg,{msg=it},modifier=Modifier.weight(1f),placeholder={Text("Message…")});IconButton(onClick={msg=""}){Icon(Icons.Default.Send,null,tint=Purple)}}}}
@Composable private fun ProfileScreen(pad:PaddingValues,settings:()->Unit,chat:()->Unit){Column(Modifier.fillMaxSize().padding(pad).background(Bg).verticalScroll(rememberScrollState()).padding(18.dp),horizontalAlignment=Alignment.CenterHorizontally){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.End){IconButton(onClick=settings){Icon(Icons.Default.Settings,null,tint=Ink)}};Avatar("ALPHA Creator",72);Text("@alpha.creator",color=Ink,fontSize=22.sp,fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=12.dp));Text("Creating moments. Connecting people. 💜",color=Muted);Row(Modifier.fillMaxWidth().padding(vertical=22.dp),horizontalArrangement=Arrangement.SpaceEvenly){Stat("248","Videos");Stat("1.2M","Followers");Stat("183","Following")};Row(horizontalArrangement=Arrangement.spacedBy(12.dp)){Button(onClick={},colors=ButtonDefaults.buttonColors(containerColor=Purple)){Text("Edit profile")};OutlinedButton(onClick=chat){Text("Message",color=Ink)}};Text("Your videos",color=Ink,fontWeight=FontWeight.Bold,modifier=Modifier.align(Alignment.Start).padding(top=28.dp));Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){repeat(3){Surface(Modifier.weight(1f).height(110.dp),color=Card,shape=RoundedCornerShape(12.dp)){Box(contentAlignment=Alignment.Center){Icon(Icons.Default.PlayArrow,null,tint=Purple)}}}}}}
@Composable private fun Avatar(name:String,size:Int=48){Box(Modifier.size(size.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Blue,Purple,Pink))),contentAlignment=Alignment.Center){Text(name.take(1).uppercase(),color=Ink,fontWeight=FontWeight.Bold,fontSize=(size/2).sp)}}
@Composable private fun Stat(value:String,label:String){Column(horizontalAlignment=Alignment.CenterHorizontally){Text(value,color=Ink,fontSize=19.sp,fontWeight=FontWeight.Bold);Text(label,color=Muted,fontSize=12.sp)}}
@Composable private fun SettingsScreen(back:()->Unit){Column(Modifier.fillMaxSize().background(Bg).padding(18.dp)){Text("‹  Settings",color=Ink,fontSize=25.sp,modifier=Modifier.clickable{back()});listOf("Account","Privacy and safety","Notifications","Content preferences","Data and storage","Language","Help and support","About ALPHA","Log out").forEach{Row(Modifier.fillMaxWidth().clickable{}.padding(vertical=16.dp),horizontalArrangement=Arrangement.SpaceBetween){Text(it,color=Ink);Text("›",color=Muted)}}}}
@Composable private fun LiveScreen(back:()->Unit){Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF29104C),Bg))),contentAlignment=Alignment.Center){Column(horizontalAlignment=Alignment.CenterHorizontally){Text("LIVE",color=Pink,fontSize=34.sp,fontWeight=FontWeight.Black);Text("Live streaming preview",color=Ink);Text("Streaming requires a configured media service",color=Muted,fontSize=12.sp,modifier=Modifier.padding(12.dp));Button(onClick=back,colors=ButtonDefaults.buttonColors(containerColor=Purple)){Text("Back to ALPHA")}}}}
