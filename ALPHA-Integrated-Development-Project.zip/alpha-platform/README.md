# ALPHA — Android short-video social platform MVP

ALPHA is an international-first short-video platform project with a Kotlin/Jetpack Compose Android app, Spring Boot API starter, PostgreSQL schema, Python recommendation scorer and React admin starter.

## Android UI/UX included
The Android app contains the end-to-end screen flow: Welcome, Onboarding, Login, Registration, For You vertical video feed, reaction picker, comments, Discover, upload picker, editor/caption form, Inbox, Chat, Creator Profile, Settings and Live preview. It uses the ALPHA midnight / blue / violet / magenta design system. The vertical video feed uses Android Media3 ExoPlayer and sample HLS streams. See `docs/ANDROID-UI-UX-IMPLEMENTATION.md` and `design/alpha-android-uiux-full.png`.

## Project modules
- `android/` — Kotlin + Jetpack Compose Android app
- `backend/` — Java Spring Boot REST API starter and PostgreSQL schema
- `recommender/` — Python recommendation scoring service
- `admin/` — React admin dashboard starter
- `design/` — visual UI/UX concept assets
- `docs/` — architecture, API, launch and implementation notes

## Run locally
### Backend + PostgreSQL + recommender
Requires Docker Desktop:
```bash
docker compose up --build
```
- API health: `http://localhost:8080/api/health`
- Recommender health: `http://localhost:8001/health`

### Admin dashboard
Requires Node.js 20+:
```bash
cd admin
npm install
npm run dev
```

### Android app
Requires Android Studio, Android SDK Platform 36 and JDK 17/21 compatible with the configured Android Gradle Plugin:
1. Open the `android/` directory in Android Studio.
2. Sync Gradle.
3. Run the `app` configuration on an Android 8.0+ emulator/device.
4. Build a debug APK via Build → Build Bundle(s) / APK(s) → Build APK(s).

## Honest implementation status
This is an MVP source project, not a production-ready social network. Android screens and local demo interactions are implemented. Feed playback uses sample HLS URLs. The backend API and database schema are starter implementations. Android-to-API authenticated integration, Firebase credentials/token verification, persistent social graph and comments, cloud video storage/transcoding/CDN, push notifications, production moderation, live streaming and payment/monetization remain deployment/integration work. The login/register forms and upload/editor flows are currently UI/demo flows; do not expose them as production functionality without completing those integrations.

## Security
Never commit Firebase service account files, signing keys, passwords or production secrets. Configure HTTPS, authenticated/authorized APIs, upload limits, malware/content scanning, rate limiting, privacy controls and data retention before launch.

## Admin console update
The `admin/` React/Vite app now includes a responsive ALPHA-branded admin workspace with navigation for Overview, Users, Videos, Moderation, Reports, Analytics, Algorithm, Live streams, Monetization, Notifications, Audit logs and Settings. The overview contains dashboard metric cards, analytics visualization, user-growth chart, moderation queue, creator ranking and activity stream. User and video actions currently update local preview state so the interface can be reviewed without a backend.

Set `VITE_ALPHA_API` in `admin/.env` (copy `.env.example`) to point to the Spring API. The UI checks `/api/health`; it falls back to clearly labelled demo data when the API is unavailable. Important: the admin UI is not yet a secure production control plane. Real admin login, role-based authorization, persistent user/video moderation endpoints, audit persistence and live metrics must be implemented and security-tested before exposing it publicly. Never treat client-side preview actions as actual moderation.

## Current delivery boundary
This archive is an integrated development starter/MVP, not a finished commercial social network. Android screens, the admin interface, starter API, schema and recommendation scorer are included. Production authentication/token validation, durable CRUD integration for all modules, cloud object storage, transcoding/HLS packaging, CDN, push delivery, live streaming provider, payment integration, abuse detection, privacy/compliance review, load testing and Play Store signing/release still require configuration and implementation. No APK has been built or device-tested in this environment.
