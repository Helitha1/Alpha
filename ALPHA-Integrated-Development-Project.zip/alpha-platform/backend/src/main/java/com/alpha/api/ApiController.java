package com.alpha.api;

import org.springframework.web.bind.annotation.*;
import java.time.Instant;
import java.util.*;
import java.nio.file.*;
import java.io.IOException;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.beans.factory.annotation.Value;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "${ALPHA_WEB_ORIGIN:http://localhost:5173}")
public class ApiController {
    private final Map<String, Map<String,Object>> demoVideos = new java.util.concurrent.ConcurrentHashMap<>();
    private final Map<String, Map<String,String>> demoReactions = new java.util.concurrent.ConcurrentHashMap<>();
    @Value("${alpha.media-dir:./data/uploads}") private String mediaDir;
    @Value("${alpha.public-base-url:http://localhost:8080}") private String publicBaseUrl;

    @GetMapping("/health")
    public Map<String,Object> health() { return Map.of("service", "alpha-api", "status", "ok", "time", Instant.now().toString()); }

    @GetMapping("/feed")
    public List<Map<String,Object>> feed(@RequestParam(defaultValue = "for-you") String type) {
        List<Map<String,Object>> items = new ArrayList<>(demoVideos.values());
        if (items.isEmpty()) items.addAll(List.of(
            video("demo-1", "alpha.creator", "A little inspiration for your day ✨", "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8", 12840),
            video("demo-2", "wander.world", "Find your next adventure 🌄", "https://test-streams.mux.dev/test_001/stream.m3u8", 8390)
        ));
        return items;
    }

    @PostMapping("/videos/{videoId}/reactions")
    public Map<String,Object> react(@PathVariable String videoId, @RequestBody ReactionRequest request) {
        if (!Set.of("LIKE", "LOVE", "HAHA", "WOW", "SAD", "ANGRY").contains(request.type().toUpperCase(Locale.ROOT)))
            throw new IllegalArgumentException("Unsupported reaction type");
        String type = request.type().toUpperCase(Locale.ROOT);
        String userId = request.userId() == null || request.userId().isBlank() ? "demo-user" : request.userId();
        demoReactions.computeIfAbsent(videoId, ignored -> new java.util.concurrent.ConcurrentHashMap<>()).put(userId, type);
        return Map.of("videoId", videoId, "userId", userId, "reaction", type, "accepted", true,
                "note", "Prototype in-memory reaction. Configure authenticated persistence before public release.");
    }

    @PostMapping(value = "/videos/upload", consumes = "multipart/form-data")
    public Map<String,Object> upload(@RequestPart("file") MultipartFile file,
                                     @RequestParam(defaultValue = "alpha.creator") String creator,
                                     @RequestParam(defaultValue = "") String caption) throws IOException {
        if (file.isEmpty() || file.getSize() > 150L * 1024 * 1024)
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Select a video up to 150 MB.");
        String contentType = Optional.ofNullable(file.getContentType()).orElse("");
        if (!contentType.startsWith("video/")) throw new ResponseStatusException(HttpStatus.UNSUPPORTED_MEDIA_TYPE, "Only video uploads are accepted.");
        String original = Optional.ofNullable(file.getOriginalFilename()).orElse("video.mp4");
        String ext = original.contains(".") ? original.substring(original.lastIndexOf('.')).replaceAll("[^.a-zA-Z0-9]", "") : ".mp4";
        String id = UUID.randomUUID().toString();
        Path root = Paths.get(mediaDir).toAbsolutePath().normalize(); Files.createDirectories(root);
        Path destination = root.resolve(id + ext).normalize();
        if (!destination.startsWith(root)) throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid filename.");
        file.transferTo(destination);
        Map<String,Object> result = new LinkedHashMap<>();
        result.put("id", id); result.put("creator", creator); result.put("caption", caption);
        result.put("playbackUrl", publicBaseUrl + "/media/" + id + ext); result.put("status", "UPLOADED_PENDING_TRANSCODE");
        demoVideos.put(id, result);
        return result;
    }

    @PostMapping("/videos/{videoId}/events")
    public Map<String,Object> event(@PathVariable String videoId, @RequestBody EventRequest event) {
        if (!Set.of("IMPRESSION", "WATCH", "COMPLETE", "REWATCH", "SKIP", "SHARE", "COMMENT").contains(event.type().toUpperCase(Locale.ROOT)))
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Unsupported event type");
        return Map.of("videoId", videoId, "accepted", true, "event", event.type().toUpperCase(Locale.ROOT), "watchMs", Math.max(0, event.watchMs()));
    }

    public record EventRequest(String type, int watchMs, boolean completed) {}
    private Map<String,Object> video(String id, String creator, String caption, String playbackUrl, int views) {
        return Map.of("id", id, "creator", creator, "caption", caption, "playbackUrl", playbackUrl, "views", views,
                "reactionCounts", Map.of("LIKE", 102, "LOVE", 31, "HAHA", 8));
    }
    public record ReactionRequest(String type, String userId) {}
}
