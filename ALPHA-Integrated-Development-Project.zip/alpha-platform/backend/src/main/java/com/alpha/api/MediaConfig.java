package com.alpha.api;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import java.nio.file.Paths;

@Configuration
public class MediaConfig implements WebMvcConfigurer {
    @Value("${alpha.media-dir:./data/uploads}") private String mediaDir;
    @Override public void addResourceHandlers(ResourceHandlerRegistry registry) {
        String location = Paths.get(mediaDir).toAbsolutePath().normalize().toUri().toString();
        registry.addResourceHandler("/media/**").addResourceLocations(location);
    }
}
