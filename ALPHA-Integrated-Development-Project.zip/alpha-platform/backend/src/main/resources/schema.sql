CREATE TABLE IF NOT EXISTS app_user (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), handle VARCHAR(30) UNIQUE NOT NULL,
 display_name VARCHAR(80) NOT NULL, bio VARCHAR(300), avatar_url TEXT,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now(), status VARCHAR(20) NOT NULL DEFAULT 'ACTIVE'
);
CREATE TABLE IF NOT EXISTS video (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), user_id UUID NOT NULL REFERENCES app_user(id),
 caption VARCHAR(2200), playback_url TEXT NOT NULL, thumbnail_url TEXT,
 duration_ms INTEGER NOT NULL CHECK (duration_ms > 0), visibility VARCHAR(20) NOT NULL DEFAULT 'PUBLIC',
 moderation_status VARCHAR(20) NOT NULL DEFAULT 'PENDING', created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS reaction (
 user_id UUID NOT NULL REFERENCES app_user(id), video_id UUID NOT NULL REFERENCES video(id) ON DELETE CASCADE,
 reaction_type VARCHAR(10) NOT NULL CHECK (reaction_type IN ('LIKE','LOVE','HAHA','WOW','SAD','ANGRY')),
 created_at TIMESTAMPTZ NOT NULL DEFAULT now(), PRIMARY KEY(user_id, video_id)
);
CREATE TABLE IF NOT EXISTS video_event (
 id BIGSERIAL PRIMARY KEY, user_id UUID REFERENCES app_user(id), video_id UUID NOT NULL REFERENCES video(id),
 event_type VARCHAR(20) NOT NULL, watch_ms INTEGER NOT NULL DEFAULT 0, completed BOOLEAN NOT NULL DEFAULT FALSE,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS follow (
 follower_id UUID NOT NULL REFERENCES app_user(id), followed_id UUID NOT NULL REFERENCES app_user(id),
 created_at TIMESTAMPTZ NOT NULL DEFAULT now(), PRIMARY KEY(follower_id, followed_id), CHECK(follower_id <> followed_id)
);
CREATE INDEX IF NOT EXISTS idx_video_feed ON video(moderation_status, visibility, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_video_event_user ON video_event(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_video_event_video ON video_event(video_id, event_type);

CREATE TABLE IF NOT EXISTS comment (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 user_id UUID NOT NULL REFERENCES app_user(id),
 video_id UUID NOT NULL REFERENCES video(id) ON DELETE CASCADE,
 body VARCHAR(1000) NOT NULL,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 status VARCHAR(20) NOT NULL DEFAULT 'VISIBLE'
);
CREATE TABLE IF NOT EXISTS video_report (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 reporter_id UUID NOT NULL REFERENCES app_user(id),
 video_id UUID REFERENCES video(id) ON DELETE CASCADE,
 reason VARCHAR(80) NOT NULL,
 details VARCHAR(1000),
 status VARCHAR(20) NOT NULL DEFAULT 'OPEN',
 created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS saved_video (
 user_id UUID NOT NULL REFERENCES app_user(id),
 video_id UUID NOT NULL REFERENCES video(id) ON DELETE CASCADE,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 PRIMARY KEY(user_id, video_id)
);
CREATE TABLE IF NOT EXISTS notification (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 user_id UUID NOT NULL REFERENCES app_user(id),
 actor_id UUID REFERENCES app_user(id),
 type VARCHAR(30) NOT NULL,
 entity_id UUID,
 read_at TIMESTAMPTZ,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_comment_video ON comment(video_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_report_status ON video_report(status, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_notification_user ON notification(user_id, created_at DESC);
